"""
Fusion 360 script: creates (or reuses) the project "WTH Window Mount Components v2.0",
uploads ./step/assembly_all_parts.step as ONE design (every part is a component inside it),
and opens it.

Fusion for personal use allows only 10 editable documents, so this deliberately does not
upload the per-part STEP files as separate documents. To get a single part out, right-click
its component in the browser and use Save As Mesh / Export.

Run it from Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S) > the + next to
"My Scripts" > pick this folder > select it > Run.
"""
import os
import time
import traceback

import adsk.core

PROJECT_NAME = "WTH Window Mount Components v2.0"
STEP_FILE = "assembly_all_parts.step"
DOC_NAME = "assembly_all_parts"
TIMEOUT_S = 300


def run(context):
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        here = os.path.dirname(os.path.realpath(__file__))
        path = os.path.join(here, "step", STEP_FILE)
        if not os.path.exists(path):
            ui.messageBox("STEP file not found:\n" + path)
            return

        project = None
        for p in app.data.dataProjects:
            if p.name == PROJECT_NAME:
                project = p
                break
        if project is None:
            project = app.data.dataProjects.add(PROJECT_NAME)
        folder = project.rootFolder

        existing = {df.name: df for df in folder.dataFiles}
        status = ""
        to_open = existing.get(DOC_NAME)
        if to_open is not None:
            status = "Already there, not uploaded again: " + DOC_NAME
        else:
            progress = ui.createProgressDialog()
            progress.isCancelButtonShown = False
            progress.show("WTH window mount v2", "Uploading " + DOC_NAME + " ...", 0, 1, 0)
            adsk.doEvents()
            future = folder.uploadFile(path)
            start = time.time()
            while future.uploadState == adsk.core.UploadStates.UploadProcessing:
                adsk.doEvents()
                time.sleep(0.5)
                if time.time() - start > TIMEOUT_S:
                    break
            progress.hide()
            if future.uploadState == adsk.core.UploadStates.UploadFinished:
                status = "Uploaded: " + DOC_NAME
                to_open = future.dataFile
            else:
                status = "Still processing or failed (check the Data Panel in a minute): " + DOC_NAME

        msg = ["Project: " + PROJECT_NAME, "", status, "",
               "One document holds every part as a component, all in millimetres.",
               "Use Inspect > Measure to check dimensions."]
        ui.messageBox("\n".join(msg))

        if to_open is not None:
            app.documents.open(to_open, True)
    except Exception:
        if ui:
            ui.messageBox("Import failed:\n{}".format(traceback.format_exc()))
