"""
Fusion 360 script: creates (or reuses) the project "WTH Window Mount Components v2.0",
uploads every STEP file in the ./step folder next to this script, and opens the assembly.

Run it from Fusion: Utilities > Add-Ins > Scripts and Add-Ins (Shift+S) > the + next to
"My Scripts" > pick this folder > select it > Run.
"""
import os
import time
import traceback

import adsk.core

PROJECT_NAME = "WTH Window Mount Components v2.0"
OPEN_AFTER = "assembly_all_parts"
TIMEOUT_S = 300


def run(context):
    app = adsk.core.Application.get()
    ui = app.userInterface
    try:
        here = os.path.dirname(os.path.realpath(__file__))
        step_dir = os.path.join(here, "step")
        files = sorted(f for f in os.listdir(step_dir) if f.lower().endswith((".step", ".stp")))
        if not files:
            ui.messageBox("No STEP files found in:\n" + step_dir)
            return

        project = None
        for p in app.data.dataProjects:
            if p.name == PROJECT_NAME:
                project = p
                break
        if project is None:
            project = app.data.dataProjects.add(PROJECT_NAME)
        folder = project.rootFolder

        existing = {df.name for df in folder.dataFiles}
        uploaded, skipped, failed = [], [], []
        to_open = None

        progress = ui.createProgressDialog()
        progress.isCancelButtonShown = False
        progress.show("WTH window mount v2", "Uploading %v of %m ...", 0, len(files), 0)

        for i, name in enumerate(files):
            base = os.path.splitext(name)[0]
            progress.progressValue = i
            progress.message = "Uploading {} (%v of %m) ...".format(base)
            adsk.doEvents()
            if base in existing:
                skipped.append(base)
                continue
            future = folder.uploadFile(os.path.join(step_dir, name))
            start = time.time()
            while future.uploadState == adsk.core.UploadStates.UploadProcessing:
                adsk.doEvents()
                time.sleep(0.5)
                if time.time() - start > TIMEOUT_S:
                    break
            if future.uploadState == adsk.core.UploadStates.UploadFinished:
                uploaded.append(base)
                if base == OPEN_AFTER:
                    to_open = future.dataFile
            else:
                failed.append(base)

        progress.hide()

        msg = ["Project: " + PROJECT_NAME, ""]
        if uploaded:
            msg.append("Uploaded: " + ", ".join(uploaded))
        if skipped:
            msg.append("Already there (skipped): " + ", ".join(skipped))
        if failed:
            msg.append("Still processing or failed (check the Data Panel in a minute): " + ", ".join(failed))
        msg += ["", "All files are in millimetres. Use Inspect > Measure to check dimensions."]
        ui.messageBox("\n".join(msg))

        if to_open is not None:
            app.documents.open(to_open, True)
    except Exception:
        if ui:
            ui.messageBox("Import failed:\n{}".format(traceback.format_exc()))
